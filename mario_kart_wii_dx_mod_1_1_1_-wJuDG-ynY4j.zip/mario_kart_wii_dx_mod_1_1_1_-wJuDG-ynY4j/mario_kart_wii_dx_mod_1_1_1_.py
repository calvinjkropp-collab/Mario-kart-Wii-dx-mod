# Online Converter, URL: http://convert.pystage.org/conversion/wJuDG-ynY4j
# mario_kart_wii_dx_mod_1_1_1_ (pyStage, converted from Scratch 3)

from pystage.en import Sprite, Stage

stage = Stage()
stage.add_backdrop('backdrop1_19')
stage.add_backdrop('backdrop2_7')
stage.create_variable('tracker')
stage.create_variable('speed!!!')
stage.create_variable('IMPORTANT!!!!!!')
stage.create_variable('charters')
stage.create_variable('username')
stage.create_variable('ghost speed!!!')
stage.show_variable("speed!!!")
stage.set_monitor_position("speed!!!", -235, 175)
stage.show_variable("username")
stage.set_monitor_position("username", -230, 145)

def when_GREENFLAG_clicked_1(self):
    self.switch_backdrop_to("backdrop1_19")
    while True:
        if (self.get_variable("tracker") == 1):
            self.switch_backdrop_to("backdrop2_7")

stage.when_GREENFLAG_clicked(when_GREENFLAG_clicked_1)

# Create and initialize sprite 'calvin'
calvin = stage.add_a_sprite(None)
calvin.set_name("calvin")
calvin.set_x(36)
calvin.set_y(28)
calvin.go_to_back_layer()
calvin.go_forward(8)
calvin.add_costume('costume1_79', center_x=43.400000000000034, center_y=87.60000000000002)
calvin.add_sound('pop_22')

# Create and initialize sprite 'charter_models'
charter_models = stage.add_a_sprite(None)
charter_models.set_name("charter models")
charter_models.set_x(-158)
charter_models.set_y(7)
charter_models.go_to_back_layer()
charter_models.go_forward(22)
charter_models.add_costume('costume1_80', center_x=56.63662289326098, center_y=77.25346264156362)
charter_models.add_costume('costume8_6', center_x=45.795802893261, center_y=-42.34160799189246)
charter_models.add_costume('costume9_6', center_x=45.795802893261, center_y=-42.34160799189246)
charter_models.add_costume('costume2_26', center_x=56.63662251435014, center_y=77.25346458934904)
charter_models.add_costume('costume7_7', center_x=55.540512703805575, center_y=5.943222181054779)
charter_models.add_costume('costume10_4', center_x=55.540512703805575, center_y=5.943222181054779)
charter_models.add_costume('costume5_9', center_x=55.63662232489472, center_y=77.25346556324175)
charter_models.add_costume('costume6_8', center_x=55.540512514350155, center_y=77.25345653713447)
charter_models.add_costume('costume3_12', center_x=56.77320322535442, center_y=63.15338916782301)
charter_models.add_costume('costume4_12', center_x=55.540509222551464, center_y=64.7388268799866)
charter_models.next_costume()
charter_models.next_costume()
charter_models.add_sound('pop_22')

# Create and initialize sprite 'text'
text = stage.add_a_sprite(None)
text.set_name("text")
text.set_x(-149)
text.set_y(-121)
text.go_to_back_layer()
text.go_forward(9)
text.add_costume('costume3_13', center_x=31.858342361863492, center_y=-9.807661451787652)
text.add_costume('costume1_81', center_x=31.858342361863492, center_y=-9.807421451787661)
text.add_costume('costume4_13', center_x=31.858342361863492, center_y=-10.375031295842831)
text.add_costume('costume5_10', center_x=31.858342361863492, center_y=-10.375031139897999)
text.add_costume('costume2_27', center_x=31.858342361863492, center_y=-9.807661451787652)
text.next_costume()
text.next_costume()
text.next_costume()
text.add_sound('pop_22')

# Create and initialize sprite 'track'
track = stage.add_a_sprite(None)
track.set_name("track")
track.set_x(26.99664276268175)
track.set_y(5.817871783473279)
track.go_to_back_layer()
track.go_forward(11)
track.hide()
track.add_costume('costume1_82', center_x=53.25207100591717, center_y=108.41557387755101)
track.add_sound('pop_22')

# Create and initialize sprite 'ground'
ground = stage.add_a_sprite(None)
ground.set_name("ground")
ground.set_x(-10)
ground.set_y(20)
ground.go_to_back_layer()
ground.go_forward(1)
ground.hide()
ground.add_costume('costume1_83', center_x=277.7627352694491, center_y=-145.2850149343679)
ground.add_sound('pop_22')

# Create and initialize sprite 'wall'
wall = stage.add_a_sprite(None)
wall.set_name("wall")
wall.set_x(204)
wall.set_y(-99)
wall.go_to_back_layer()
wall.go_forward(5)
wall.set_size_to(46)
wall.hide()
wall.add_costume('costume2_28', center_x=102.82498168945312, center_y=-25.20907650605588)
wall.add_sound('pop_22')

# Create and initialize sprite 'wall_2'
wall_2 = stage.add_a_sprite(None)
wall_2.set_name("Wall 2")
wall_2.set_x(-138)
wall_2.set_y(-69)
wall_2.go_to_back_layer()
wall_2.go_forward(3)
wall_2.set_size_to(92)
wall_2.hide()
wall_2.add_costume('costume2_28', center_x=102.82498168945312, center_y=-25.20907650605588)
wall_2.add_sound('pop_22')

# Create and initialize sprite 'slime'
slime = stage.add_a_sprite(None)
slime.set_name("slime")
slime.set_x(154.72402453324025)
slime.set_y(31.397075154538904)
slime.go_to_back_layer()
slime.go_forward(10)
slime.add_costume('costume1_84', center_x=43.400000000000034, center_y=87.60000000000002)
slime.add_sound('pop_22')

# Create and initialize sprite 'wall_3'
wall_3 = stage.add_a_sprite(None)
wall_3.set_name("wall 3")
wall_3.set_x(-143)
wall_3.set_y(-108)
wall_3.go_to_back_layer()
wall_3.go_forward(2)
wall_3.set_size_to(23)
wall_3.hide()
wall_3.add_costume('costume2_28', center_x=102.82498168945312, center_y=-25.20907650605588)
wall_3.add_sound('pop_22')

# Create and initialize sprite 'red_shellshell'
red_shellshell = stage.add_a_sprite(None)
red_shellshell.set_name("red shellshell")
red_shellshell.set_x(174)
red_shellshell.set_y(-145)
red_shellshell.go_to_back_layer()
red_shellshell.go_forward(19)
red_shellshell.set_size_to(23)
red_shellshell.hide()
red_shellshell.add_costume('red_shell', center_x=320, center_y=280, factor=2)

# Create and initialize sprite 'wall_3'
wall_3 = stage.add_a_sprite(None)
wall_3.set_name("Wall 3")
wall_3.set_x(-138)
wall_3.set_y(-69)
wall_3.go_to_back_layer()
wall_3.go_forward(4)
wall_3.set_size_to(92)
wall_3.hide()
wall_3.add_costume('costume2_28', center_x=102.82498168945312, center_y=-25.20907650605588)
wall_3.add_sound('pop_22')

# Create and initialize sprite 'wall2'
wall2 = stage.add_a_sprite(None)
wall2.set_name("wall2")
wall2.set_x(204)
wall2.set_y(-99)
wall2.go_to_back_layer()
wall2.go_forward(6)
wall2.set_size_to(46)
wall2.hide()
wall2.add_costume('costume2_28', center_x=102.82498168945312, center_y=-25.20907650605588)
wall2.add_sound('pop_22')

# Create and initialize sprite 'goal'
goal = stage.add_a_sprite(None)
goal.set_name("goal")
goal.set_x(-123)
goal.set_y(-108)
goal.go_to_back_layer()
goal.go_forward(7)
goal.set_size_to(16)
goal.hide()
goal.add_costume('costume1_85', center_x=191.32498168945312, center_y=3.5751800537109375)
goal.add_sound('pop_22')

# Create and initialize sprite 'sprite1'
sprite1 = stage.add_a_sprite(None)
sprite1.set_name("Sprite1")
sprite1.set_x(0.9994681595414576)
sprite1.set_y(143.0002144711574)
sprite1.go_to_back_layer()
sprite1.go_forward(12)
sprite1.hide()
sprite1.add_costume('costume1_86', center_x=81.1942036836403, center_y=45.864572047670435)
sprite1.add_sound('pop_22')

# Create and initialize sprite 'sprite2'
sprite2 = stage.add_a_sprite(None)
sprite2.set_name("Sprite2")
sprite2.set_x(316.52081298828125)
sprite2.set_y(26.0018310546875)
sprite2.go_to_back_layer()
sprite2.go_forward(16)
sprite2.add_costume('costume1_87', center_x=140.33831176757812, center_y=49.99310302734375)
sprite2.add_sound('pop_22')

# Create and initialize sprite 'sprite3'
sprite3 = stage.add_a_sprite(None)
sprite3.set_name("Sprite3")
sprite3.set_x(-87.46026215135132)
sprite3.set_y(-33.75866145338088)
sprite3.go_to_back_layer()
sprite3.go_forward(13)
sprite3.add_costume('costume1_88', center_x=145.37187675502844, center_y=35.59423248350981)
sprite3.add_sound('pop_22')

# Create and initialize sprite 'sprite4'
sprite4 = stage.add_a_sprite(None)
sprite4.set_name("Sprite4")
sprite4.set_x(-40.28169433812542)
sprite4.set_y(10.142761781417946)
sprite4.go_to_back_layer()
sprite4.go_forward(15)
sprite4.add_costume('costume1_89', center_x=130.68472964112152, center_y=50.29073143291902)
sprite4.add_sound('pop_22')

# Create and initialize sprite 'sprite5'
sprite5 = stage.add_a_sprite(None)
sprite5.set_name("Sprite5")
sprite5.set_x(-40.838691341345054)
sprite5.set_y(-71.8490854637783)
sprite5.go_to_back_layer()
sprite5.go_forward(14)
sprite5.add_costume('costume1_89', center_x=130.68472964112152, center_y=50.29073143291902)
sprite5.add_sound('pop_22')

# Create and initialize sprite 'sprite6'
sprite6 = stage.add_a_sprite(None)
sprite6.set_name("Sprite6")
sprite6.set_x(9.25799007536915)
sprite6.set_y(-34.15430864876542)
sprite6.go_to_back_layer()
sprite6.go_forward(18)
sprite6.add_costume('costume1_88', center_x=145.37187675502844, center_y=35.59423248350981)
sprite6.add_sound('pop_22')

# Create and initialize sprite 'sprite7'
sprite7 = stage.add_a_sprite(None)
sprite7.set_name("Sprite7")
sprite7.set_x(319.41154523680916)
sprite7.set_y(-172.7067909117233)
sprite7.go_to_back_layer()
sprite7.go_forward(17)
sprite7.hide()
sprite7.add_costume('costume1_90', center_x=140.33832176757812, center_y=49.99310302734378)
sprite7.add_sound('pop_22')

# Create and initialize sprite 'charter_models2'
charter_models2 = stage.add_a_sprite(None)
charter_models2.set_name("charter models2")
charter_models2.set_x(-158)
charter_models2.set_y(7)
charter_models2.go_to_back_layer()
charter_models2.go_forward(20)
charter_models2.set_size_to(107)
charter_models2.hide()
charter_models2.add_costume('costume2_26', center_x=56.63662251435014, center_y=77.25346458934904)
charter_models2.add_costume('costume5_9', center_x=55.63662232489472, center_y=77.25346556324175)
charter_models2.add_costume('costume3_12', center_x=56.77320322535442, center_y=63.15338916782301)
charter_models2.add_costume('costume4_12', center_x=55.540509222551464, center_y=64.7388268799866)
charter_models2.add_sound('pop_22')

# Create and initialize sprite 'sprite8'
sprite8 = stage.add_a_sprite(None)
sprite8.set_name("Sprite8")
sprite8.set_x(217.9897248439331)
sprite8.set_y(148.05428855085103)
sprite8.go_to_back_layer()
sprite8.go_forward(21)
sprite8.set_size_to(50)
sprite8.add_costume('costume1_91', center_x=142.09213424789309, center_y=51.02557905096586)
sprite8.add_sound('pop_22')

# Create and initialize sprite 'slime2'
slime2 = stage.add_a_sprite(None)
slime2.set_name("slime2")
slime2.set_x(37.62789924943612)
slime2.set_y(-59.08135334260724)
slime2.go_to_back_layer()
slime2.go_forward(23)
slime2.add_costume('costume1_92', center_x=43.400000000000034, center_y=87.60000000000002)
slime2.add_sound('pop_22')

# Scratch Blocks for 'calvin'

def when_this_sprite_clicked_2(self):
    self.change_variable_by("tracker", 1.0)

calvin.when_this_sprite_clicked(when_this_sprite_clicked_2)

def when_program_starts_3(self):
    while True:
        if (self.get_variable("tracker") == 0):
            self.show()

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.hide()

calvin.when_program_starts(when_program_starts_3)

def when_i_receive_message_4(self):
    "NO TRANSLATION: data_showlist"
    "NO TRANSLATION: data_hidelist"
    "NO TRANSLATION: data_addtolist"

calvin.when_i_receive_message("Goal!", when_i_receive_message_4)

def when_program_starts_5(self):
    while True:
        if ("NO TRANSLATION: data_lengthoflist" > 0):
            self.set_variable("username", "NO TRANSLATION: data_itemoflist")
            "NO TRANSLATION: data_hidelist"

        self.wait(100.0)
        "NO TRANSLATION: data_showlist"

calvin.when_program_starts(when_program_starts_5)

def when_program_starts_6(self):
    "NO TRANSLATION: data_hidelist"
    "NO TRANSLATION: data_showlist"
    while True:
        if (self.get_variable("tracker") == 2):
            self.reset_timer()
            "NO TRANSLATION: data_hidelist"
            self.stop_this_script()

calvin.when_program_starts(when_program_starts_6)

# Scratch Blocks for 'charter_models'

def when_program_starts_7(self):
    self.set_variable("speed!!!", 0)
    self.switch_costume_to("costume1_80")
    self.go_to_x_y(-158.0, 7.0)
    self.go_to_front_layer()
    while True:
        if (self.get_variable("tracker") == 2):
            if (self.costume_number() == 1):
                self.go_to_x_y(-10.0, -66.0)
                self.switch_costume_to("costume2_26")
                while True:
                    if self.key_pressed("space"):
                        self.wait(0.001)
                        self.change_variable_by("speed!!!", 1.0)
                        if self.key_pressed("up arrow"):
                            self.switch_costume_to("costume2_26")
                            self.broadcast("FUCKERS")
                            self.wait(0.5)
                            "NO TRANSLATION: data_addtolist"

                        if self.key_pressed("right arrow"):
                            self.switch_costume_to("costume3_12")
                            self.broadcast("right")
                            "NO TRANSLATION: data_addtolist"

                        if self.key_pressed("left arrow"):
                            self.switch_costume_to("costume4_12")
                            self.broadcast("left")

                        if self.key_pressed("down arrow"):
                            self.switch_costume_to("costume6_8")
                            self.switch_costume_to("costume5_9")
                            self.broadcast("back")

                    if (self.costume_number() == 9):
                        self.switch_costume_to("costume10_4")
                        self.go_to_x_y(-10.0, -66.0)
                        while True:
                            if self.key_pressed("space"):
                                self.wait(0.001)
                                self.change_variable_by("speed!!!", 1.0)
                                if (self.get_variable("speed!!!") == 11):
                                    self.set_variable("speed!!!", 10)

                                if self.key_pressed("up arrow"):
                                    self.broadcast("FUCKERS")
                                    self.wait(0.5)

                            if self.key_pressed("right arrow"):
                                self.broadcast("right")
                                if (self.costume_number() == 2):
                                    self.switch_costume_to("costume7_7")
                                    self.go_to_x_y(-10.0, -66.0)
                                    while True:
                                        if self.key_pressed("space"):
                                            self.wait(0.001)
                                            self.change_variable_by("speed!!!", 1.0)
                                            if (self.get_variable("speed!!!") == 11):
                                                self.set_variable("speed!!!", 10)

                                            if self.key_pressed("up arrow"):
                                                self.broadcast("FUCKERS")
                                                self.wait(0.5)

                                            if self.key_pressed("right arrow"):
                                                self.broadcast("right")

                                            if self.key_pressed("left arrow"):
                                                self.broadcast("left")

                                            if self.key_pressed("down arrow"):
                                                self.broadcast("back")

                            if self.key_pressed("left arrow"):
                                self.broadcast("left")

                            if self.key_pressed("down arrow"):
                                self.broadcast("back")

charter_models.when_program_starts(when_program_starts_7)

def when_i_receive_message_8(self):
    self.switch_costume_to("costume8_6")

charter_models.when_i_receive_message("SLIME!", when_i_receive_message_8)

def when_i_receive_message_9(self):
    self.hide()

charter_models.when_i_receive_message("Goal!", when_i_receive_message_9)

def when_program_starts_10(self):
    while True:
        if (self.get_variable("tracker") == 0):
            self.show()

        if (self.get_variable("tracker") == 1):
            self.show()

        if (self.get_variable("tracker") == 2):
            self.show()

        if (self.get_variable("tracker") == "ghost"):
            self.hide()

charter_models.when_program_starts(when_program_starts_10)

def when_program_starts_11(self):
    self.set_variable("speed!!!", 20)
    while True:
        if (self.get_variable("speed!!!") < 20):
            self.set_variable("speed!!!", 20)

charter_models.when_program_starts(when_program_starts_11)

def when_i_receive_message_12(self):
    self.switch_costume_to("costume9_6")

charter_models.when_i_receive_message("sufuer cube", when_i_receive_message_12)

# Scratch Blocks for 'text'

def when_program_starts_13(self):
    self.switch_costume_to("costume2_27")
    self.go_to_x_y(-4.0, 181.0)
    self.create_clone_of_myself()
    self.switch_costume_to("costume3_13")
    self.go_to_x_y(-20.0, 179.0)
    self.create_clone_of_myself()
    self.switch_costume_to("costume1_81")
    self.go_to_x_y(-149.0, -121.0)
    while True:
        if (self.get_variable("tracker") == 2):
            self.hide()

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 0):
            self.show()

text.when_program_starts(when_program_starts_13)

def when_i_start_as_a_clone_14(self):
    self.hide()
    while True:
        if ((self.costume_number() > 2) and (self.get_variable("tracker") == 0)):
            self.show()

        if ((self.costume_number() > 3) and (self.get_variable("tracker") == 0)):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.hide()

        if ((self.costume_number() == 3) and (self.get_variable("tracker") == 1)):
            self.show()

        if ((self.costume_number() > 2) and (self.get_variable("tracker") == 1)):
            self.hide()

text.when_i_start_as_a_clone(when_i_start_as_a_clone_14)

def when_i_receive_message_15(self):
    self.switch_costume_to("costume5_10")

text.when_i_receive_message("sufuer cube", when_i_receive_message_15)

def when_i_receive_message_16(self):
    self.switch_costume_to("costume4_13")

text.when_i_receive_message("SLIME!", when_i_receive_message_16)

# Scratch Blocks for 'track'

def when_program_starts_17(self):
    self.hide()
    while True:
        if (self.get_variable("tracker") == 1):
            self.show()

        if (self.get_variable("tracker") == 2):
            self.hide()

track.when_program_starts(when_program_starts_17)

def when_this_sprite_clicked_18(self):
    self.change_variable_by("tracker", 1.0)

track.when_this_sprite_clicked(when_this_sprite_clicked_18)

def when_program_starts_19(self):
    self.set_variable("tracker", 0)

track.when_program_starts(when_program_starts_19)

# Scratch Blocks for 'ground'

def when_program_starts_20(self):
    self.hide()
    self.go_to_back_layer()
    while True:
        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.show()

ground.when_program_starts(when_program_starts_20)

def when_i_receive_message_21(self):
    self.hide()

ground.when_i_receive_message("Goal!", when_i_receive_message_21)

def when_program_starts_22(self):
    pass

ground.when_program_starts(when_program_starts_22)

# Scratch Blocks for 'wall'

def when_i_receive_message_23(self):
    self.change_size_by(self.get_variable("speed!!!"))
    self.change_y_by(self.get_variable("speed!!!"))

wall.when_i_receive_message("FUCKERS", when_i_receive_message_23)

def when_program_starts_24(self):
    self.hide()
    self.go_to_back_layer()
    self.go_forward(1)
    while True:
        if (200 < self.size()):
            while True:
                self.hide()

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.show()

        if self.touching(wall_2):
            self.go_to_sprite("NO TRANSLATION: motion_goto_menu")
            self.change_x_by(84.0)

wall.when_program_starts(when_program_starts_24)

def when_i_receive_message_25(self):
    self.change_size_by(-10.0)

wall.when_i_receive_message("back", when_i_receive_message_25)

def when_i_receive_message_26(self):
    self.change_x_by(-10.0)

wall.when_i_receive_message("left", when_i_receive_message_26)

def when_i_receive_message_27(self):
    self.change_x_by(10.0)

wall.when_i_receive_message("right", when_i_receive_message_27)

def when_program_starts_28(self):
    self.set_size_to(46.0)
    self.go_to_x_y(204.0, -99.0)

wall.when_program_starts(when_program_starts_28)

def when_program_starts_29(self):
    while True:
        if (self.touching(charter_models) and (self.size() > 190)):
            self.go_to_front_layer()

        if (self.touching(charter_models) and (self.pick_random(170.0, 180.0) > self.size())):
            self.go_to_back_layer()
            self.go_forward(1)
            self.set_variable("speed!!!", 0)
            if (self.size() > 167):
                self.set_size_to(166.0)

wall.when_program_starts(when_program_starts_29)

def when_program_starts_30(self):
    while True:
        if (self.x_position() > 380):
            self.go_to_x_y(204.0, -99.0)

wall.when_program_starts(when_program_starts_30)

def when_program_starts_31(self):
    self.set_ghost_effect_to(32.0)

wall.when_program_starts(when_program_starts_31)

def when_i_receive_message_32(self):
    self.hide()

wall.when_i_receive_message("Goal!", when_i_receive_message_32)

# Scratch Blocks for 'wall_2'

def when_i_receive_message_33(self):
    self.change_size_by(self.get_variable("speed!!!"))
    self.change_y_by("".join([self.get_variable("speed!!!"), "-"]))

wall_2.when_i_receive_message("FUCKERS", when_i_receive_message_33)

def when_program_starts_34(self):
    self.hide()
    self.go_to_back_layer()
    self.go_forward(1)
    while True:
        if (200 < self.size()):
            while True:
                self.hide()

        if self.touching(wall):
            self.go_to_sprite("NO TRANSLATION: motion_goto_menu")
            self.change_x_by(-84.0)

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.show()

wall_2.when_program_starts(when_program_starts_34)

def when_i_receive_message_35(self):
    self.change_size_by(-10.0)

wall_2.when_i_receive_message("back", when_i_receive_message_35)

def when_i_receive_message_36(self):
    self.change_x_by(-10.0)

wall_2.when_i_receive_message("left", when_i_receive_message_36)

def when_i_receive_message_37(self):
    self.change_x_by(10.0)

wall_2.when_i_receive_message("right", when_i_receive_message_37)

def when_program_starts_38(self):
    self.set_size_to(92.0)
    self.go_to_x_y(-138.0, -69.0)

wall_2.when_program_starts(when_program_starts_38)

def when_program_starts_39(self):
    while True:
        if (self.touching(charter_models) and (self.size() > 190)):
            self.go_to_front_layer()

        if (self.touching(charter_models) and (self.pick_random(170.0, 180.0) > self.size())):
            self.go_to_back_layer()
            self.go_forward(1)
            self.set_variable("speed!!!", 0)
            if (self.size() > 167):
                self.set_size_to(166.0)

wall_2.when_program_starts(when_program_starts_39)

def when_program_starts_40(self):
    while True:
        if (self.x_position() > 380):
            self.go_to_x_y(-138.0, -69.0)

wall_2.when_program_starts(when_program_starts_40)

def when_program_starts_41(self):
    self.set_ghost_effect_to(32.0)

wall_2.when_program_starts(when_program_starts_41)

def when_i_receive_message_42(self):
    self.hide()

wall_2.when_i_receive_message("Goal!", when_i_receive_message_42)

# Scratch Blocks for 'slime'

def when_this_sprite_clicked_43(self):
    self.change_variable_by("tracker", 1.0)
    self.broadcast("SLIME!")

slime.when_this_sprite_clicked(when_this_sprite_clicked_43)

def when_program_starts_44(self):
    while True:
        if (self.get_variable("tracker") == 0):
            self.show()

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.hide()

slime.when_program_starts(when_program_starts_44)

# Scratch Blocks for 'wall_3'

def when_i_receive_message_45(self):
    self.change_size_by(self.get_variable("speed!!!"))
    self.change_y_by(self.get_variable("speed!!!"))

wall_3.when_i_receive_message("FUCKERS", when_i_receive_message_45)

def when_program_starts_46(self):
    self.hide()
    self.go_to_back_layer()
    self.go_forward(1)
    while True:
        if (200 < self.size()):
            while True:
                self.hide()

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.show()

        if self.touching(wall_2):
            self.go_to_sprite("NO TRANSLATION: motion_goto_menu")
            self.change_x_by(84.0)

wall_3.when_program_starts(when_program_starts_46)

def when_i_receive_message_47(self):
    self.change_size_by(-10.0)

wall_3.when_i_receive_message("back", when_i_receive_message_47)

def when_i_receive_message_48(self):
    self.change_x_by(-10.0)

wall_3.when_i_receive_message("left", when_i_receive_message_48)

def when_i_receive_message_49(self):
    self.change_x_by(10.0)

wall_3.when_i_receive_message("right", when_i_receive_message_49)

def when_program_starts_50(self):
    self.set_size_to(23.0)
    self.go_to_x_y(-143.0, -108.0)

wall_3.when_program_starts(when_program_starts_50)

def when_program_starts_51(self):
    while True:
        if (self.touching(charter_models) and (self.size() > 190)):
            self.go_to_front_layer()

        if (self.touching(charter_models) and (self.pick_random(170.0, 180.0) > self.size())):
            self.go_to_back_layer()
            self.go_forward(1)
            self.set_variable("speed!!!", 0)
            if (self.size() > 167):
                self.set_size_to(166.0)

wall_3.when_program_starts(when_program_starts_51)

def when_program_starts_52(self):
    while True:
        if (self.x_position() > 380):
            self.go_to_x_y(-143.0, -108.0)

wall_3.when_program_starts(when_program_starts_52)

def when_program_starts_53(self):
    self.set_ghost_effect_to(32.0)

wall_3.when_program_starts(when_program_starts_53)

def when_i_receive_message_54(self):
    self.hide()

wall_3.when_i_receive_message("Goal!", when_i_receive_message_54)

def when_program_starts_55(self):
    "NO TRANSLATION: data_deletealloflist"
    self.set_variable("username", 0)

wall_3.when_program_starts(when_program_starts_55)

# Scratch Blocks for 'red_shellshell'

def when_program_starts_56(self):
    self.hide()
    self.go_to_back_layer()
    self.go_forward(1)
    while True:
        if (200 < self.size()):
            while True:
                self.hide()

        if self.touching(wall_2):
            self.go_to_sprite("NO TRANSLATION: motion_goto_menu")
            self.change_x_by(84.0)

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.show()

red_shellshell.when_program_starts(when_program_starts_56)

def when_i_receive_message_57(self):
    self.change_size_by(-10.0)

red_shellshell.when_i_receive_message("back", when_i_receive_message_57)

def when_i_receive_message_58(self):
    self.change_size_by(self.get_variable("speed!!!"))
    self.change_y_by("".join([self.get_variable("speed!!!"), "-"]))

red_shellshell.when_i_receive_message("FUCKERS", when_i_receive_message_58)

def when_i_receive_message_59(self):
    self.change_x_by(10.0)
    self.go_to_x_y(174.0, -145.0)

red_shellshell.when_i_receive_message("right", when_i_receive_message_59)

def when_i_receive_message_60(self):
    self.change_x_by(-10.0)

red_shellshell.when_i_receive_message("left", when_i_receive_message_60)

def when_program_starts_61(self):
    self.go_to_front_layer()
    self.set_size_to(23.0)

red_shellshell.when_program_starts(when_program_starts_61)

def when_i_receive_message_62(self):
    while True:
        self.hide()

red_shellshell.when_i_receive_message("delete red shell", when_i_receive_message_62)

def when_program_starts_63(self):
    while True:
        if (self.x_position() > 380):
            self.go_to_x_y(174.0, -145.0)

red_shellshell.when_program_starts(when_program_starts_63)

def when_program_starts_64(self):
    self.set_ghost_effect_to(32.0)

red_shellshell.when_program_starts(when_program_starts_64)

def when_i_receive_message_65(self):
    self.hide()

red_shellshell.when_i_receive_message("Goal!", when_i_receive_message_65)

# Scratch Blocks for 'wall_3'

def when_i_receive_message_66(self):
    self.change_size_by(self.get_variable("speed!!!"))
    self.change_y_by("".join([self.get_variable("speed!!!"), "-"]))

wall_3.when_i_receive_message("FUCKERS", when_i_receive_message_66)

def when_program_starts_67(self):
    self.hide()
    self.go_to_back_layer()
    self.go_forward(1)
    while True:
        if (200 < self.size()):
            while True:
                self.hide()

        if self.touching(wall):
            self.go_to_sprite("NO TRANSLATION: motion_goto_menu")
            self.change_x_by(-84.0)

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.show()

wall_3.when_program_starts(when_program_starts_67)

def when_i_receive_message_68(self):
    self.change_size_by(-10.0)

wall_3.when_i_receive_message("back", when_i_receive_message_68)

def when_i_receive_message_69(self):
    self.change_x_by(-10.0)

wall_3.when_i_receive_message("left", when_i_receive_message_69)

def when_i_receive_message_70(self):
    self.change_x_by(10.0)

wall_3.when_i_receive_message("right", when_i_receive_message_70)

def when_program_starts_71(self):
    self.set_size_to(92.0)
    self.go_to_x_y(-138.0, -69.0)

wall_3.when_program_starts(when_program_starts_71)

def when_program_starts_72(self):
    while True:
        if (self.touching(charter_models) and (self.size() > 190)):
            self.go_to_front_layer()

        if (self.touching(charter_models) and (self.pick_random(170.0, 180.0) > self.size())):
            self.go_to_back_layer()
            self.go_forward(1)
            self.set_variable("speed!!!", 0)
            if (self.size() > 167):
                self.set_size_to(166.0)

wall_3.when_program_starts(when_program_starts_72)

def when_program_starts_73(self):
    while True:
        if (self.x_position() > 380):
            self.go_to_x_y(-138.0, -69.0)

wall_3.when_program_starts(when_program_starts_73)

def when_program_starts_74(self):
    self.set_ghost_effect_to(32.0)

wall_3.when_program_starts(when_program_starts_74)

def when_i_receive_message_75(self):
    self.hide()

wall_3.when_i_receive_message("Goal!", when_i_receive_message_75)

# Scratch Blocks for 'wall2'

def when_i_receive_message_76(self):
    self.change_size_by(self.get_variable("speed!!!"))
    self.change_y_by(self.get_variable("speed!!!"))

wall2.when_i_receive_message("FUCKERS", when_i_receive_message_76)

def when_program_starts_77(self):
    self.hide()
    self.go_to_back_layer()
    self.go_forward(1)
    while True:
        if (200 < self.size()):
            while True:
                self.hide()

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.show()

        if self.touching(wall_2):
            self.go_to_sprite("NO TRANSLATION: motion_goto_menu")
            self.change_x_by(84.0)

wall2.when_program_starts(when_program_starts_77)

def when_i_receive_message_78(self):
    self.change_size_by(-10.0)

wall2.when_i_receive_message("back", when_i_receive_message_78)

def when_i_receive_message_79(self):
    self.change_x_by(-10.0)

wall2.when_i_receive_message("left", when_i_receive_message_79)

def when_i_receive_message_80(self):
    self.change_x_by(10.0)

wall2.when_i_receive_message("right", when_i_receive_message_80)

def when_program_starts_81(self):
    self.set_size_to(46.0)
    self.go_to_x_y(204.0, -99.0)

wall2.when_program_starts(when_program_starts_81)

def when_program_starts_82(self):
    while True:
        if (self.touching(charter_models) and (self.size() > 190)):
            self.go_to_front_layer()

        if (self.touching(charter_models) and (self.pick_random(170.0, 180.0) > self.size())):
            self.go_to_back_layer()
            self.go_forward(1)
            self.set_variable("speed!!!", 0)
            if (self.size() > 167):
                self.set_size_to(166.0)

wall2.when_program_starts(when_program_starts_82)

def when_program_starts_83(self):
    while True:
        if (self.x_position() > 380):
            self.go_to_x_y(204.0, -99.0)

wall2.when_program_starts(when_program_starts_83)

def when_program_starts_84(self):
    self.set_ghost_effect_to(32.0)

wall2.when_program_starts(when_program_starts_84)

def when_i_receive_message_85(self):
    self.hide()

wall2.when_i_receive_message("Goal!", when_i_receive_message_85)

# Scratch Blocks for 'goal'

def when_program_starts_86(self):
    self.hide()
    self.set_size_to(16.0)

goal.when_program_starts(when_program_starts_86)

def when_i_receive_message_87(self):
    self.change_size_by(self.get_variable("speed!!!"))
    self.change_y_by("".join([self.get_variable("speed!!!"), "-"]))

goal.when_i_receive_message("FUCKERS", when_i_receive_message_87)

def when_i_receive_message_88(self):
    self.change_size_by(-10.0)
    self.wait(1e-30)
    self.go_to_back_layer()
    self.go_forward(1)
    self.go_to_x_y(-143.0, -108.0)
    while True:
        if (250 < self.size()):
            while True:
                self.hide()

        if self.touching(wall):
            self.go_to_sprite("NO TRANSLATION: motion_goto_menu")
            self.change_x_by(-84.0)

        if (self.get_variable("tracker") == 1):
            self.hide()

goal.when_i_receive_message("back", when_i_receive_message_88)

def when_i_receive_message_89(self):
    self.change_x_by(10.0)

goal.when_i_receive_message("right", when_i_receive_message_89)

def when_i_receive_message_90(self):
    self.change_x_by(-10.0)

goal.when_i_receive_message("left", when_i_receive_message_90)

def when_program_starts_91(self):
    self.set_ghost_effect_to(32.0)

goal.when_program_starts(when_program_starts_91)

def when_program_starts_92(self):
    while True:
        if (self.x_position() > 380):
            self.go_to_x_y(-143.0, -108.0)

goal.when_program_starts(when_program_starts_92)

def when_program_starts_93(self):
    while True:
        if (self.touching(charter_models) and (self.size() > 167)):
            self.go_to_front_layer()
            self.broadcast("Goal!")

        if (self.touching(charter_models) and (168 > self.size())):
            self.go_to_back_layer()

goal.when_program_starts(when_program_starts_93)

def when_i_receive_message_94(self):
    self.hide()

goal.when_i_receive_message("Goal!", when_i_receive_message_94)

def when_program_starts_95(self):
    while True:
        if (self.get_variable("tracker") == 2):
            self.show()

goal.when_program_starts(when_program_starts_95)

# Scratch Blocks for 'sprite1'

def when_i_receive_message_96(self):
    self.show()
    self.set_variable("speed!!!", 0)

sprite1.when_i_receive_message("Goal!", when_i_receive_message_96)

def when_program_starts_97(self):
    self.hide()
    self.reset_timer()

sprite1.when_program_starts(when_program_starts_97)

# Scratch Blocks for 'sprite2'

def when_program_starts_98(self):
    self.set_ghost_effect_to(46.0)

sprite2.when_program_starts(when_program_starts_98)

def when_this_sprite_clicked_99(self):
    while True:
        self.change_variable_by("speed!!!", 1.0)

sprite2.when_this_sprite_clicked(when_this_sprite_clicked_99)

# Scratch Blocks for 'sprite3'

def when_program_starts_100(self):
    self.set_ghost_effect_to(46.0)

sprite3.when_program_starts(when_program_starts_100)

def when_this_sprite_clicked_101(self):
    self.broadcast("left")

sprite3.when_this_sprite_clicked(when_this_sprite_clicked_101)

# Scratch Blocks for 'sprite4'

def when_program_starts_102(self):
    self.set_ghost_effect_to(46.0)

sprite4.when_program_starts(when_program_starts_102)

def when_this_sprite_clicked_103(self):
    self.broadcast("FUCKERS")

sprite4.when_this_sprite_clicked(when_this_sprite_clicked_103)

# Scratch Blocks for 'sprite5'

def when_program_starts_104(self):
    self.set_ghost_effect_to(46.0)

sprite5.when_program_starts(when_program_starts_104)

def when_this_sprite_clicked_105(self):
    self.broadcast("back")

sprite5.when_this_sprite_clicked(when_this_sprite_clicked_105)

# Scratch Blocks for 'sprite6'

def when_program_starts_106(self):
    self.set_ghost_effect_to(46.0)

sprite6.when_program_starts(when_program_starts_106)

def when_this_sprite_clicked_107(self):
    self.broadcast("right")

sprite6.when_this_sprite_clicked(when_this_sprite_clicked_107)

# Scratch Blocks for 'sprite7'

def when_program_starts_108(self):
    self.hide()
    self.set_ghost_effect_to(46.0)
    while True:
        if self.key_pressed("0"):
            while True:
                self.show()

sprite7.when_program_starts(when_program_starts_108)

def when_this_sprite_clicked_109(self):
    "NO TRANSLATION: data_deletealloflist"

sprite7.when_this_sprite_clicked(when_this_sprite_clicked_109)

# Scratch Blocks for 'charter_models2'

def when_program_starts_110(self):
    self.set_variable("speed!!!", 0)
    self.switch_costume_to("costume2_26")
    self.go_to_x_y(-158.0, 7.0)
    self.go_to_front_layer()
    self.hide()
    while True:
        if (self.get_variable("tracker") == "ghost"):
            self.show()
            if (self.costume_number() == 2):
                self.go_to_x_y(-10.0, -66.0)
                self.switch_costume_to("costume2_26")
                while True:
                    if ("NO TRANSLATION: data_itemoflist" == "FORWARD"):
                        self.change_size_by(-1.0)
                        self.switch_costume_to("costume2_26")
                        "NO TRANSLATION: data_deleteoflist"

                    if ("NO TRANSLATION: data_itemoflist" == "BACK"):
                        self.change_size_by(1.0)
                        self.switch_costume_to("costume5_9")
                        "NO TRANSLATION: data_deleteoflist"

                    if ("NO TRANSLATION: data_itemoflist" == "RIGHT"):
                        self.change_x_by(1.0)
                        self.switch_costume_to("costume3_12")
                        "NO TRANSLATION: data_deleteoflist"

                    if ("NO TRANSLATION: data_itemoflist" == "LEFT"):
                        self.change_x_by(-1.0)
                        self.switch_costume_to("costume4_12")
                        "NO TRANSLATION: data_deleteoflist"

charter_models2.when_program_starts(when_program_starts_110)

def when_i_receive_message_111(self):
    self.hide()

charter_models2.when_i_receive_message("Goal!", when_i_receive_message_111)

def when_program_starts_112(self):
    while True:
        if (self.get_variable("tracker") == 0):
            self.hide()

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.hide()

        if (self.get_variable("tracker") == "ghost"):
            self.show()

charter_models2.when_program_starts(when_program_starts_112)

def when_program_starts_113(self):
    self.set_variable("speed!!!", 20)
    while True:
        if (self.get_variable("speed!!!") < 20):
            self.set_variable("speed!!!", 20)

charter_models2.when_program_starts(when_program_starts_113)

def when_i_receive_message_114(self):
    self.change_x_by(-10.0)

charter_models2.when_i_receive_message("left", when_i_receive_message_114)

def when_i_receive_message_115(self):
    self.change_x_by(10.0)

charter_models2.when_i_receive_message("right", when_i_receive_message_115)

def when_program_starts_116(self):
    self.set_ghost_effect_to(56.0)

charter_models2.when_program_starts(when_program_starts_116)

def when_i_receive_message_117(self):
    self.change_size_by(-10.0)

charter_models2.when_i_receive_message("back", when_i_receive_message_117)

def when_i_receive_message_118(self):
    self.change_size_by(self.get_variable("speed!!!"))
    self.change_y_by("".join([self.get_variable("speed!!!"), "-"]))

charter_models2.when_i_receive_message("FUCKERS", when_i_receive_message_118)

# Scratch Blocks for 'sprite8'

def when_this_sprite_clicked_119(self):
    self.set_variable("tracker", "Ghost")

sprite8.when_this_sprite_clicked(when_this_sprite_clicked_119)

def when_program_starts_120(self):
    while True:
        if (self.get_variable("tracker") == 0):
            self.show()
            "NO TRANSLATION: data_showlist"

        if (self.get_variable("tracker") == 1):
            self.hide()
            "NO TRANSLATION: data_hidelist"

        if (self.get_variable("tracker") == 2):
            self.hide()
            "NO TRANSLATION: data_hidelist"

        if (self.get_variable("tracker") == "ghost"):
            self.hide()
            "NO TRANSLATION: data_hidelist"

sprite8.when_program_starts(when_program_starts_120)

# Scratch Blocks for 'slime2'

def when_this_sprite_clicked_121(self):
    self.change_variable_by("tracker", 1.0)
    self.broadcast("sufuer cube")

slime2.when_this_sprite_clicked(when_this_sprite_clicked_121)

def when_program_starts_122(self):
    while True:
        if (self.get_variable("tracker") == 0):
            self.show()

        if (self.get_variable("tracker") == 1):
            self.hide()

        if (self.get_variable("tracker") == 2):
            self.hide()

slime2.when_program_starts(when_program_starts_122)

stage.play()
